import { Router, type Request, type Response } from "express";
import { pool } from "@workspace/db";

const router = Router();

// ── /api/calendar ──────────────────────────────────────────────────────────────
router.all("/calendar", async (req: Request, res: Response) => {
  if (!process.env.DATABASE_URL) {
    return res.status(500).json({ success: false, error: "DATABASE_URL not configured" });
  }
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS calendar_events (
      id SERIAL PRIMARY KEY, title VARCHAR(500) NOT NULL, event_date DATE NOT NULL,
      type VARCHAR(50) DEFAULT 'event', created_at TIMESTAMP DEFAULT NOW()
    )`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_calendar_events_date ON calendar_events(event_date)`);
    await pool.query(`DELETE FROM calendar_events WHERE event_date < CURRENT_DATE - INTERVAL '1 year'`);

    if (req.method === "GET") {
      const events = await pool.query(`SELECT id, title, event_date, type FROM calendar_events ORDER BY event_date ASC`);
      return res.status(200).json({ success: true, data: events.rows });
    }
    if (req.method === "POST") {
      const { id, title, event_date, type } = req.body;
      if (!title || !event_date) return res.status(422).json({ success: false, error: "title and event_date required" });
      let result;
      if (id) {
        result = await pool.query(
          `UPDATE calendar_events SET title=$1, event_date=$2, type=$3 WHERE id=$4 RETURNING id, title, event_date, type`,
          [title, event_date, type ?? "event", Number(id)]
        );
      } else {
        result = await pool.query(
          `INSERT INTO calendar_events (title, event_date, type) VALUES ($1, $2, $3) RETURNING id, title, event_date, type`,
          [title, event_date, type ?? "event"]
        );
      }
      return res.status(201).json({ success: true, data: result.rows[0] });
    }
    if (req.method === "DELETE") {
      const { id } = req.query;
      if (!id) return res.status(400).json({ success: false, error: "Event ID required" });
      await pool.query(`DELETE FROM calendar_events WHERE id = $1`, [Number(id)]);
      return res.status(200).json({ success: true });
    }
    return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Server error";
    return res.status(500).json({ success: false, error: message });
  }
});

// ── /api/deliveries ────────────────────────────────────────────────────────────
router.all("/deliveries", async (req: Request, res: Response) => {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS deliveries (
      id SERIAL PRIMARY KEY, tracking_no VARCHAR(100) UNIQUE NOT NULL,
      recipient_name VARCHAR(255), address TEXT, status VARCHAR(50) DEFAULT 'pending',
      delivery_date DATE, notes TEXT, created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
    )`);
    if (req.method === "GET") {
      const result = await pool.query(`SELECT * FROM deliveries ORDER BY created_at DESC LIMIT 1000`);
      return res.status(200).json({ success: true, data: result.rows });
    }
    if (req.method === "POST") {
      const { tracking_no, recipient_name, address, status, delivery_date, notes } = req.body;
      if (!tracking_no) return res.status(422).json({ success: false, error: "tracking_no required" });
      const result = await pool.query(
        `INSERT INTO deliveries (tracking_no, recipient_name, address, status, delivery_date, notes)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (tracking_no) DO UPDATE
           SET recipient_name=EXCLUDED.recipient_name, address=EXCLUDED.address, status=EXCLUDED.status,
               delivery_date=EXCLUDED.delivery_date, notes=EXCLUDED.notes, updated_at=NOW()
         RETURNING *`,
        [tracking_no, recipient_name ?? null, address ?? null, status ?? "pending", delivery_date ?? null, notes ?? null]
      );
      return res.status(201).json({ success: true, data: result.rows[0] });
    }
    if (req.method === "DELETE") {
      const { id } = req.query;
      if (!id) return res.status(400).json({ success: false, error: "Delivery ID required" });
      await pool.query(`DELETE FROM deliveries WHERE id = $1`, [Number(id)]);
      return res.status(200).json({ success: true });
    }
    return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Server error";
    return res.status(500).json({ success: false, error: message });
  }
});

// ── /api/notes ─────────────────────────────────────────────────────────────────
router.all("/notes", async (req: Request, res: Response) => {
  await pool.query(`CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY, type VARCHAR(20) NOT NULL DEFAULT 'note', title VARCHAR(500) NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '', version VARCHAR(50) DEFAULT NULL, author VARCHAR(255) DEFAULT 'Admin',
    pinned BOOLEAN DEFAULT FALSE, created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
  )`);
  if (req.method === "GET") {
    const { type } = req.query;
    let result;
    if (type === "note") result = await pool.query(`SELECT * FROM notes WHERE type='note' ORDER BY pinned DESC, created_at DESC`);
    else if (type === "changelog") result = await pool.query(`SELECT * FROM notes WHERE type='changelog' ORDER BY created_at DESC`);
    else result = await pool.query(`SELECT * FROM notes ORDER BY type ASC, pinned DESC, created_at DESC`);
    return res.status(200).json({ success: true, data: result.rows });
  }
  if (req.method === "POST") {
    const { id, type, title, content, version, author, pinned } = req.body;
    if (!id || !type || !content) return res.status(400).json({ success: false, error: "id, type and content required" });
    await pool.query(
      `INSERT INTO notes (id, type, title, content, version, author, pinned, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
       ON CONFLICT (id) DO UPDATE
         SET title=EXCLUDED.title, content=EXCLUDED.content, version=EXCLUDED.version,
             author=EXCLUDED.author, pinned=EXCLUDED.pinned, updated_at=NOW()`,
      [id, type, title ?? "", content, version ?? null, author ?? "Admin", pinned ?? false]
    );
    return res.status(200).json({ success: true });
  }
  if (req.method === "DELETE") {
    const { id } = req.query;
    if (!id || typeof id !== "string") return res.status(400).json({ success: false, error: "id required" });
    await pool.query(`DELETE FROM notes WHERE id = $1`, [id]);
    return res.status(200).json({ success: true });
  }
  return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
});

// ── /api/plano ─────────────────────────────────────────────────────────────────
router.all("/plano", async (req: Request, res: Response) => {
  await pool.query(`CREATE TABLE IF NOT EXISTS plano_vm (id TEXT PRIMARY KEY, pages JSONB DEFAULT '[]', updated_at TIMESTAMP DEFAULT NOW())`);
  await pool.query(`INSERT INTO plano_vm (id, pages) VALUES ('default', '[]') ON CONFLICT (id) DO NOTHING`);
  if (req.method === "GET") {
    const result = await pool.query(`SELECT pages FROM plano_vm WHERE id = 'default'`);
    return res.status(200).json({ success: true, data: result.rows[0]?.pages ?? [] });
  }
  if (req.method === "POST") {
    const { pages } = req.body;
    if (!Array.isArray(pages)) return res.status(400).json({ success: false, error: "pages array required" });
    await pool.query(`UPDATE plano_vm SET pages=$1, updated_at=NOW() WHERE id='default'`, [JSON.stringify(pages)]);
    return res.status(200).json({ success: true });
  }
  return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
});

// ── /api/proxy-image ───────────────────────────────────────────────────────────
router.get("/proxy-image", async (req: Request, res: Response) => {
  const { url } = req.query;
  if (!url || typeof url !== "string") return res.status(400).json({ error: "URL parameter required" });
  if (!url.match(/^https?:\/\//)) return res.status(400).json({ error: "Only HTTP/HTTPS URLs allowed" });
  if (url.length > 2000) return res.status(400).json({ error: "URL too long" });
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { "User-Agent": "QR-Scanner-Bot/1.0" } });
    clearTimeout(timeout);
    if (!response.ok) return res.status(response.status).json({ error: "Failed to fetch image" });
    const contentType = response.headers.get("content-type");
    if (!contentType?.startsWith("image/")) return res.status(415).json({ error: "Not an image" });
    const buffer = await response.arrayBuffer();
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=3600");
    return res.status(200).send(Buffer.from(buffer));
  } catch {
    clearTimeout(timeout);
    return res.status(500).json({ error: "Failed to fetch image" });
  }
});

// ── /api/rooster ───────────────────────────────────────────────────────────────
router.all("/rooster", async (req: Request, res: Response) => {
  await pool.query(`CREATE TABLE IF NOT EXISTS rooster_resources (
    id TEXT PRIMARY KEY, name VARCHAR(200) NOT NULL, role VARCHAR(100) DEFAULT '',
    color VARCHAR(20) DEFAULT '#3B82F6', created_at TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS rooster_shifts (
    id TEXT PRIMARY KEY, resource_id TEXT NOT NULL REFERENCES rooster_resources(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL, shift_date DATE NOT NULL, start_hour INTEGER NOT NULL DEFAULT 8,
    end_hour INTEGER NOT NULL DEFAULT 16, color VARCHAR(20) NOT NULL DEFAULT '#3B82F6', created_at TIMESTAMP DEFAULT NOW()
  )`);
  if (req.method === "GET") {
    const resources = await pool.query(`SELECT id, name, role, color FROM rooster_resources ORDER BY created_at ASC`);
    const shifts = await pool.query(`SELECT id, resource_id, title, shift_date, start_hour, end_hour, color FROM rooster_shifts ORDER BY shift_date ASC, start_hour ASC`);
    return res.status(200).json({ success: true, resources: resources.rows, shifts: shifts.rows });
  }
  if (req.method === "POST") {
    const { type } = req.body;
    if (type === "resource") {
      const { id, name, role, color } = req.body;
      if (!id || !name) return res.status(400).json({ success: false, error: "id and name required" });
      await pool.query(
        `INSERT INTO rooster_resources (id, name, role, color) VALUES ($1,$2,$3,$4)
         ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, role=EXCLUDED.role, color=EXCLUDED.color`,
        [id, name, role ?? "", color ?? "#3B82F6"]
      );
      return res.status(200).json({ success: true });
    }
    if (type === "shift") {
      const { id, resource_id, title, shift_date, start_hour, end_hour, color } = req.body;
      if (!id || !resource_id || !title || !shift_date) return res.status(400).json({ success: false, error: "id, resource_id, title, shift_date required" });
      await pool.query(
        `INSERT INTO rooster_shifts (id, resource_id, title, shift_date, start_hour, end_hour, color)
         VALUES ($1,$2,$3,$4,$5,$6,$7)
         ON CONFLICT (id) DO UPDATE SET resource_id=EXCLUDED.resource_id, title=EXCLUDED.title,
           shift_date=EXCLUDED.shift_date, start_hour=EXCLUDED.start_hour, end_hour=EXCLUDED.end_hour, color=EXCLUDED.color`,
        [id, resource_id, title, shift_date, start_hour ?? 8, end_hour ?? 16, color ?? "#3B82F6"]
      );
      return res.status(200).json({ success: true });
    }
    return res.status(400).json({ success: false, error: 'type must be "resource" or "shift"' });
  }
  if (req.method === "DELETE") {
    const { type, id } = req.query;
    if (!id) return res.status(400).json({ success: false, error: "id required" });
    if (type === "resource") { await pool.query(`DELETE FROM rooster_resources WHERE id = $1`, [String(id)]); return res.status(200).json({ success: true }); }
    if (type === "shift") { await pool.query(`DELETE FROM rooster_shifts WHERE id = $1`, [String(id)]); return res.status(200).json({ success: true }); }
    return res.status(400).json({ success: false, error: 'type must be "resource" or "shift"' });
  }
  return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
});

// ── /api/route-notes ───────────────────────────────────────────────────────────
router.all("/route-notes", async (req: Request, res: Response) => {
  await pool.query(`CREATE TABLE IF NOT EXISTS route_notes (
    id TEXT PRIMARY KEY, route_id TEXT NOT NULL, type VARCHAR(20) NOT NULL DEFAULT 'note',
    text TEXT NOT NULL DEFAULT '', created_at TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_route_notes_route_id ON route_notes(route_id)`);
  if (req.method === "GET") {
    const { routeId } = req.query;
    if (!routeId || typeof routeId !== "string") return res.status(400).json({ success: false, error: "routeId required" });
    const notes = await pool.query(`SELECT * FROM route_notes WHERE route_id=$1 AND type='note' ORDER BY created_at DESC`, [routeId]);
    const changelog = await pool.query(`SELECT * FROM route_notes WHERE route_id=$1 AND type='changelog' ORDER BY created_at DESC LIMIT 200`, [routeId]);
    return res.status(200).json({ success: true, notes: notes.rows, changelog: changelog.rows });
  }
  if (req.method === "POST") {
    const { id, routeId, type, text } = req.body;
    if (!id || !routeId || !type || !text) return res.status(400).json({ success: false, error: "id, routeId, type, text required" });
    await pool.query(
      `INSERT INTO route_notes (id, route_id, type, text) VALUES ($1,$2,$3,$4) ON CONFLICT (id) DO NOTHING`,
      [id, routeId, type, text]
    );
    return res.status(200).json({ success: true });
  }
  if (req.method === "DELETE") {
    const { type, id, routeId } = req.query;
    if (routeId && type === "changelog") {
      if (typeof routeId !== "string") return res.status(400).json({ success: false, error: "routeId required" });
      await pool.query(`DELETE FROM route_notes WHERE route_id=$1 AND type='changelog'`, [routeId]);
      return res.status(200).json({ success: true });
    }
    if (!id || typeof id !== "string") return res.status(400).json({ success: false, error: "id required" });
    await pool.query(`DELETE FROM route_notes WHERE id=$1 AND type='note'`, [id]);
    return res.status(200).json({ success: true });
  }
  return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
});

// ── /api/routes ────────────────────────────────────────────────────────────────
router.all("/routes", async (req: Request, res: Response) => {
  await pool.query(`CREATE TABLE IF NOT EXISTS routes (
    id TEXT PRIMARY KEY, name VARCHAR(255) NOT NULL, code VARCHAR(100) NOT NULL,
    shift VARCHAR(50) DEFAULT 'AM', delivery_points JSONB DEFAULT '[]',
    color VARCHAR(20) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
  )`);
  await pool.query(`ALTER TABLE routes ADD COLUMN IF NOT EXISTS color VARCHAR(20) DEFAULT NULL`);
  if (req.method === "GET") {
    const result = await pool.query(`SELECT * FROM routes ORDER BY created_at ASC`);
    const routes = result.rows.map((row) => ({
      id: row.id, name: row.name, code: row.code, shift: row.shift,
      color: row.color ?? null,
      deliveryPoints: row.delivery_points, updatedAt: row.updated_at,
    }));
    return res.status(200).json({ success: true, data: routes });
  }
  if (req.method === "POST") {
    const { routes, changedRouteIds } = req.body;
    if (!Array.isArray(routes)) return res.status(400).json({ success: false, error: "routes array required" });
    const changedIds: string[] = Array.isArray(changedRouteIds) ? changedRouteIds : [];
    const ids = routes.map((r: { id: string }) => r.id);
    if (ids.length > 0) {
      await pool.query(`DELETE FROM routes WHERE id != ALL($1::text[])`, [ids]);
    } else {
      await pool.query(`DELETE FROM routes`);
    }
    for (const route of routes) {
      const isChanged = changedIds.includes(route.id);
      await pool.query(
        `INSERT INTO routes (id, name, code, shift, delivery_points, color, updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,NOW())
         ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, code=EXCLUDED.code, shift=EXCLUDED.shift,
           delivery_points=EXCLUDED.delivery_points, color=EXCLUDED.color,
           updated_at=CASE WHEN $7 THEN NOW() ELSE routes.updated_at END`,
        [route.id, route.name, route.code, route.shift, JSON.stringify(route.deliveryPoints), route.color ?? null, isChanged]
      );
    }
    return res.status(200).json({ success: true });
  }
  if (req.method === "PATCH") {
    const { id, color } = req.body;
    if (!id || !color) return res.status(400).json({ success: false, error: "id and color required" });
    await pool.query(`UPDATE routes SET color=$1, updated_at=NOW() WHERE id=$2`, [color, id]);
    return res.status(200).json({ success: true });
  }
  return res.status(405).json({ success: false, error: `Method ${req.method} not allowed` });
});

// ── /api/upload ────────────────────────────────────────────────────────────────
router.post("/upload", async (req: Request, res: Response) => {
  const apiKey = process.env.IMGBB_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ success: false, error: "Image service not configured" });
  }
  const contentType = req.headers["content-type"];
  if (!contentType?.includes("multipart/form-data")) {
    return res.status(400).json({ success: false, error: "Content-Type must be multipart/form-data" });
  }
  try {
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk as string));
    }
    const body = Buffer.concat(chunks);
    const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
      method: "POST",
      headers: { "content-type": contentType },
      body,
    });
    const payload = await response.json() as { success?: boolean; data?: { display_url?: string; url?: string }; error?: { message?: string } };
    if (!response.ok || !payload?.success) {
      throw new Error(payload?.error?.message ?? "Upload failed");
    }
    const imageUrl = payload.data?.display_url ?? payload.data?.url;
    if (!imageUrl) throw new Error("Upload succeeded without an image URL");
    return res.status(200).json({ success: true, data: { url: imageUrl } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed";
    return res.status(500).json({ success: false, error: message });
  }
});

export default router;
